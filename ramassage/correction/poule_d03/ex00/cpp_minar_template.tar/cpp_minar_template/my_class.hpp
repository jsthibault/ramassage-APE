/**
 **	Workshop c++
 **	Template
 **	Epitech Tech 2
**/

#include <iostream>

template <class T>
class	my_class {

  T	element;

public:
  my_class(T arg) {
    element=arg;
    std::cout << "Default ctor called" << std::endl;
  }

  my_class(my_class const &tmp) {
    this->element = tmp.element;
    std::cout << "Copy ctor has been called" << std::endl;
  }

  my_class& operator=(my_class const &tmp) {
    std::cout << "assignation operator called" << std::endl;
    if (&tmp != this)
      this->element = tmp.element;
    return (*this);
  }

  void	action() {
    if (typeid(element) == typeid(int))
      std::cout << "Element has been increased : " << ++element << std::endl;
    else
      std::cout << "Element is not an int" << std::endl;
  }

  ~my_class() {std::cout << "the object has been deleted" << std::endl;}
};

template <>
class	my_class <const char *> {
  const char *element;
public:
  my_class(const char * arg) {
    element = arg;
    std::cout << "Default ctor called" << std::endl;
  }
  void	action() {
    std::cout << "The element is now egual to : " << element << std::endl;
  }
  ~my_class() {};
};
